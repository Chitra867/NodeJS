import { Sidebar } from "@/components/layout/sidebar";
import { StatsCards } from "@/components/dashboard/stats-cards";
import { ThreatChart } from "@/components/dashboard/threat-chart";
import { TimelineChart } from "@/components/dashboard/timeline-chart";
import { RecentEvents } from "@/components/dashboard/recent-events";

export default function Dashboard() {
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Security Dashboard</h1>
          <p className="text-slate-400">Real-time threat monitoring and analysis</p>
        </div>

        <StatsCards />

        {/* Charts Section */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <ThreatChart />
          <TimelineChart />
        </div>

        <RecentEvents />
      </div>
    </div>
  );
}
