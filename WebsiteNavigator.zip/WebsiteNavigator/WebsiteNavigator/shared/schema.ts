import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // admin, analyst, user
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  scanType: text("scan_type").notNull(), // threat, malware, process
  results: jsonb("results").notNull(),
  threatLevel: text("threat_level").notNull(), // low, medium, high
  confidenceScore: integer("confidence_score").notNull(),
  status: text("status").notNull().default("completed"), // pending, completed, failed
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const processes = pgTable("processes", {
  id: serial("id").primaryKey(),
  pid: integer("pid").notNull(),
  name: text("name").notNull(),
  cpuUsage: integer("cpu_usage").notNull(),
  memoryUsage: text("memory_usage").notNull(),
  riskScore: integer("risk_score").notNull(),
  status: text("status").notNull().default("running"), // running, stopped, suspicious
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const threatEvents = pgTable("threat_events", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // malware, insider_threat, suspicious_process
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(), // low, medium, high, critical
  userId: integer("user_id"),
  resolved: boolean("resolved").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  createdAt: true,
});

export const insertProcessSchema = createInsertSchema(processes).omit({
  id: true,
  createdAt: true,
});

export const insertThreatEventSchema = createInsertSchema(threatEvents).omit({
  id: true,
  createdAt: true,
});

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Scan = typeof scans.$inferSelect;
export type InsertScan = z.infer<typeof insertScanSchema>;
export type Process = typeof processes.$inferSelect;
export type InsertProcess = z.infer<typeof insertProcessSchema>;
export type ThreatEvent = typeof threatEvents.$inferSelect;
export type InsertThreatEvent = z.infer<typeof insertThreatEventSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
