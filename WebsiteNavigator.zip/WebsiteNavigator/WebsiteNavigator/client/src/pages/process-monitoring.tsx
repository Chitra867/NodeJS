import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Play, Square, Download, Eye, X, Activity } from "lucide-react";
import type { Process } from "@shared/schema";

export default function ProcessMonitoring() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isScanning, setIsScanning] = useState(false);

  const { data: processes, isLoading } = useQuery<Process[]>({
    queryKey: ["/api/processes", user?.id],
    enabled: !!user?.id,
  });

  const scanMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("User not authenticated");
      const response = await apiRequest("POST", `/api/processes/scan/${user.id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/processes", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/threats/recent"] });
      
      toast({
        title: "System scan completed",
        description: "Process monitoring data has been updated",
      });
      setIsScanning(false);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Scan failed",
        description: "Failed to perform system scan",
      });
      setIsScanning(false);
    },
  });

  const handleStartScan = () => {
    setIsScanning(true);
    scanMutation.mutate();
  };

  const handleStopScan = () => {
    setIsScanning(false);
    toast({
      title: "Scan stopped",
      description: "System scan has been stopped",
    });
  };

  const handleExportLogs = () => {
    toast({
      title: "Exporting logs",
      description: "Process logs are being prepared for download",
    });
  };

  const getRiskScoreColor = (score: number) => {
    if (score >= 70) return "text-red-400";
    if (score >= 40) return "text-orange-400";
    return "text-green-400";
  };

  const getRiskScoreWidth = (score: number) => {
    return `${score}%`;
  };

  const getRiskScoreFillClass = (score: number) => {
    if (score >= 70) return "risk-fill-high";
    if (score >= 40) return "risk-fill-medium";
    return "risk-fill-low";
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "suspicious":
        return "destructive";
      case "stopped":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "suspicious":
        return "High Risk";
      case "stopped":
        return "Stopped";
      default:
        return "Safe";
    }
  };

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">System Process Monitoring</h1>
          <p className="text-slate-400">Real-time monitoring of system processes with AI-powered risk assessment</p>
        </div>

        {/* Control Panel */}
        <Card className="bg-slate-800 border-slate-700 mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button 
                  onClick={handleStartScan}
                  disabled={isScanning}
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  <Play className="w-4 h-4 mr-2" />
                  {isScanning ? "Scanning..." : "Start Scan"}
                </Button>
                <Button 
                  onClick={handleStopScan}
                  disabled={!isScanning}
                  variant="secondary"
                  className="bg-slate-600 hover:bg-slate-500"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </Button>
                <Button 
                  onClick={handleExportLogs}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Logs
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${isScanning ? 'bg-green-400 animate-pulse' : 'bg-slate-600'}`}></div>
                <span className="text-sm text-slate-400">
                  {isScanning ? "Active Monitoring" : "Monitoring Stopped"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Process Table */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle>Running Processes</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="animate-pulse flex space-x-4 p-4 bg-slate-700 rounded-lg">
                    <div className="h-4 bg-slate-600 rounded w-16"></div>
                    <div className="h-4 bg-slate-600 rounded w-32"></div>
                    <div className="h-4 bg-slate-600 rounded w-20"></div>
                    <div className="h-4 bg-slate-600 rounded w-24"></div>
                    <div className="h-4 bg-slate-600 rounded w-20"></div>
                  </div>
                ))}
              </div>
            ) : !processes || processes.length === 0 ? (
              <div className="text-center py-8">
                <Activity className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-400">No processes found</p>
                <p className="text-slate-500 text-sm">Start a system scan to monitor processes</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700">
                      <TableHead>PID</TableHead>
                      <TableHead>Process Name</TableHead>
                      <TableHead>CPU %</TableHead>
                      <TableHead>Memory</TableHead>
                      <TableHead>Risk Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {processes.map((process) => (
                      <TableRow key={process.id} className="border-slate-700 hover:bg-slate-700/50">
                        <TableCell className="font-mono text-sm">{process.pid}</TableCell>
                        <TableCell>{process.name}</TableCell>
                        <TableCell>{process.cpuUsage}%</TableCell>
                        <TableCell>{process.memoryUsage}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div className="risk-bar">
                              <div 
                                className={`h-2 rounded-full ${getRiskScoreFillClass(process.riskScore)}`}
                                style={{ width: getRiskScoreWidth(process.riskScore) }}
                              ></div>
                            </div>
                            <span className={`text-sm font-medium ${getRiskScoreColor(process.riskScore)}`}>
                              {process.riskScore}/100
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusVariant(process.status)}>
                            {getStatusLabel(process.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
