import { 
  users, 
  scans, 
  processes, 
  threatEvents,
  type User, 
  type InsertUser, 
  type Scan, 
  type InsertScan,
  type Process,
  type InsertProcess,
  type ThreatEvent,
  type InsertThreatEvent
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Scans
  getScan(id: number): Promise<Scan | undefined>;
  getUserScans(userId: number): Promise<Scan[]>;
  createScan(scan: InsertScan): Promise<Scan>;
  getAllScans(): Promise<Scan[]>;
  
  // Processes
  getProcess(id: number): Promise<Process | undefined>;
  getUserProcesses(userId: number): Promise<Process[]>;
  createProcess(process: InsertProcess): Promise<Process>;
  updateProcessStatus(id: number, status: string): Promise<Process | undefined>;
  
  // Threat Events
  getThreatEvent(id: number): Promise<ThreatEvent | undefined>;
  getUserThreatEvents(userId: number): Promise<ThreatEvent[]>;
  createThreatEvent(event: InsertThreatEvent): Promise<ThreatEvent>;
  getRecentThreatEvents(limit?: number): Promise<ThreatEvent[]>;
  markThreatResolved(id: number): Promise<ThreatEvent | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private scans: Map<number, Scan>;
  private processes: Map<number, Process>;
  private threatEvents: Map<number, ThreatEvent>;
  private currentUserId: number;
  private currentScanId: number;
  private currentProcessId: number;
  private currentThreatEventId: number;

  constructor() {
    this.users = new Map();
    this.scans = new Map();
    this.processes = new Map();
    this.threatEvents = new Map();
    this.currentUserId = 1;
    this.currentScanId = 1;
    this.currentProcessId = 1;
    this.currentThreatEventId = 1;
    
    // Create default admin user
    this.createUser({
      username: "admin",
      email: "admin@secureai.com",
      password: "admin123",
      role: "admin"
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      role: insertUser.role || "user",
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  // Scans
  async getScan(id: number): Promise<Scan | undefined> {
    return this.scans.get(id);
  }

  async getUserScans(userId: number): Promise<Scan[]> {
    return Array.from(this.scans.values()).filter(scan => scan.userId === userId);
  }

  async createScan(insertScan: InsertScan): Promise<Scan> {
    const id = this.currentScanId++;
    const scan: Scan = { 
      ...insertScan, 
      status: insertScan.status || "completed",
      id, 
      createdAt: new Date() 
    };
    this.scans.set(id, scan);
    return scan;
  }

  async getAllScans(): Promise<Scan[]> {
    return Array.from(this.scans.values());
  }

  // Processes
  async getProcess(id: number): Promise<Process | undefined> {
    return this.processes.get(id);
  }

  async getUserProcesses(userId: number): Promise<Process[]> {
    return Array.from(this.processes.values()).filter(process => process.userId === userId);
  }

  async createProcess(insertProcess: InsertProcess): Promise<Process> {
    const id = this.currentProcessId++;
    const process: Process = { 
      ...insertProcess, 
      status: insertProcess.status || "running",
      id, 
      createdAt: new Date() 
    };
    this.processes.set(id, process);
    return process;
  }

  async updateProcessStatus(id: number, status: string): Promise<Process | undefined> {
    const process = this.processes.get(id);
    if (process) {
      const updatedProcess = { ...process, status };
      this.processes.set(id, updatedProcess);
      return updatedProcess;
    }
    return undefined;
  }

  // Threat Events
  async getThreatEvent(id: number): Promise<ThreatEvent | undefined> {
    return this.threatEvents.get(id);
  }

  async getUserThreatEvents(userId: number): Promise<ThreatEvent[]> {
    return Array.from(this.threatEvents.values())
      .filter(event => event.userId === userId || event.userId === null);
  }

  async createThreatEvent(insertEvent: InsertThreatEvent): Promise<ThreatEvent> {
    const id = this.currentThreatEventId++;
    const event: ThreatEvent = { 
      ...insertEvent, 
      userId: insertEvent.userId || null,
      resolved: insertEvent.resolved || false,
      id, 
      createdAt: new Date() 
    };
    this.threatEvents.set(id, event);
    return event;
  }

  async getRecentThreatEvents(limit: number = 10): Promise<ThreatEvent[]> {
    return Array.from(this.threatEvents.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async markThreatResolved(id: number): Promise<ThreatEvent | undefined> {
    const event = this.threatEvents.get(id);
    if (event) {
      const updatedEvent = { ...event, resolved: true };
      this.threatEvents.set(id, updatedEvent);
      return updatedEvent;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
