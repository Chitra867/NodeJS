# AI-Integrated Predictive Behavioral Analytics Framework

## Overview

This is a full-stack web application that implements an AI-integrated predictive behavioral analytics framework for detecting insider threats and malware through system process monitoring. The application provides a comprehensive cybersecurity dashboard with file upload capabilities, real-time monitoring, and threat detection analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Framework**: Radix UI components with Tailwind CSS for styling
- **Component Library**: Shadcn/ui components for consistent design system

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Style**: RESTful API with JSON responses
- **Session Management**: In-memory storage for development (production-ready database integration available)
- **File Processing**: Express middleware for handling file uploads and processing

### Database & Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon serverless)
- **Migration Tool**: Drizzle Kit for schema migrations
- **Development Storage**: In-memory storage implementation for rapid prototyping

## Key Components

### Authentication System
- **Implementation**: Custom authentication with JWT-style user sessions
- **Features**: Login, signup, and role-based access control
- **Roles**: Admin, analyst, and regular user permissions
- **Storage**: User credentials stored securely with password hashing

### Dashboard Components
- **Stats Cards**: Real-time metrics display for scans, threats, and system health
- **Threat Visualization**: Interactive charts using Chart.js for threat distribution
- **Timeline Analysis**: Historical threat detection patterns
- **Recent Events**: Live feed of security events and alerts

### File Processing System
- **Upload Handler**: Multi-file upload with progress tracking
- **Analysis Engine**: Simulated AI analysis for threat detection
- **File Types**: Support for PDFs, CSVs, and system logs
- **Results Storage**: Scan results with confidence scoring and threat levels

### Process Monitoring
- **Real-time Scanning**: System process monitoring with risk assessment
- **Process Tracking**: CPU and memory usage monitoring
- **Threat Classification**: Automated risk scoring for running processes
- **Alert System**: Notifications for suspicious process behavior

## Data Flow

1. **User Authentication**: Users authenticate through the login system, receiving session tokens
2. **File Upload**: Users upload files through the web interface with progress tracking
3. **AI Analysis**: Files are processed through simulated AI algorithms for threat detection
4. **Data Storage**: Results are stored in the database with metadata and confidence scores
5. **Dashboard Updates**: Real-time updates to dashboard metrics and visualizations
6. **Process Monitoring**: Continuous monitoring of system processes with risk assessment
7. **Alert Generation**: Automated alerts for high-risk threats and suspicious activities

## External Dependencies

### Frontend Libraries
- **UI Components**: Radix UI primitives for accessibility and functionality
- **Styling**: Tailwind CSS for utility-first styling approach
- **Icons**: Lucide React for consistent iconography
- **Charts**: Chart.js for data visualization
- **Forms**: React Hook Form with Zod validation

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL for production deployment
- **ORM**: Drizzle ORM for type-safe database operations
- **Validation**: Zod for runtime type validation
- **Session Storage**: Connect-pg-simple for PostgreSQL session storage

### Development Tools
- **Build System**: Vite with React plugin for fast development
- **Type Checking**: TypeScript for compile-time type safety
- **Code Quality**: ESLint and Prettier for code formatting
- **Development Server**: Express with Vite integration for seamless development

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Database**: In-memory storage for rapid prototyping
- **Build Process**: Vite build for frontend, esbuild for backend compilation

### Production Deployment
- **Frontend**: Static build optimized for CDN deployment
- **Backend**: Node.js server with Express.js
- **Database**: PostgreSQL with Neon serverless for scalability
- **Environment**: Environment variables for configuration management

### Build Configuration
- **Frontend Build**: Vite produces optimized static assets
- **Backend Build**: esbuild creates bundled server application
- **Database Migrations**: Drizzle Kit handles schema migrations
- **Asset Management**: Tailwind CSS purging for minimal bundle size

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout the stack, and scalable deployment options. The simulated AI components provide realistic threat detection capabilities while maintaining development simplicity.