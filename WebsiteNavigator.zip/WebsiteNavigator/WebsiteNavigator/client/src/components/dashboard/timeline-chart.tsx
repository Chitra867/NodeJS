import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect, useRef } from "react";

declare global {
  interface Window {
    Chart: any;
  }
}

export function TimelineChart() {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["/api/charts/timeline"],
  });

  useEffect(() => {
    if (!data || !chartRef.current) return;

    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // Load Chart.js
    if (!window.Chart) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.onload = () => {
        createChart();
      };
      document.head.appendChild(script);
    } else {
      createChart();
    }

    function createChart() {
      if (!chartRef.current || !data) return;

      chartInstance.current = new window.Chart(chartRef.current, {
        type: 'line',
        data: {
          labels: data.labels,
          datasets: data.datasets.map((dataset: any) => ({
            ...dataset,
            tension: 0.4
          }))
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: {
                color: '#94A3B8'
              }
            }
          },
          scales: {
            y: {
              grid: {
                color: '#374151'
              },
              ticks: {
                color: '#94A3B8'
              }
            },
            x: {
              grid: {
                color: '#374151'
              },
              ticks: {
                color: '#94A3B8'
              }
            }
          }
        }
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle>Detection Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle>Detection Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <canvas ref={chartRef}></canvas>
        </div>
      </CardContent>
    </Card>
  );
}
