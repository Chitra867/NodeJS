import { apiRequest } from "./queryClient";
import type { User, LoginRequest, InsertUser } from "@shared/schema";

export interface AuthResponse {
  user: Omit<User, 'password'>;
}

export async function login(credentials: LoginRequest): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/login", credentials);
  return response.json();
}

export async function signup(userData: InsertUser): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/signup", userData);
  return response.json();
}

export function logout(): void {
  localStorage.removeItem("user");
}

export function getCurrentUser(): Omit<User, 'password'> | null {
  const userStr = localStorage.getItem("user");
  return userStr ? JSON.parse(userStr) : null;
}

export function setCurrentUser(user: Omit<User, 'password'>): void {
  localStorage.setItem("user", JSON.stringify(user));
}
