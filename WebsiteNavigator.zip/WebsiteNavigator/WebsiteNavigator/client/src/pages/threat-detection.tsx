import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { AlertTriangle, Shield, Activity, TrendingUp } from "lucide-react";
import type { Scan } from "@shared/schema";

export default function ThreatDetection() {
  const { user } = useAuth();
  
  const { data: scans, isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans", user?.id],
    enabled: !!user?.id,
  });

  const threats = scans?.filter(scan => scan.threatLevel === "high") || [];
  const mediumThreats = scans?.filter(scan => scan.threatLevel === "medium") || [];
  const lowThreats = scans?.filter(scan => scan.threatLevel === "low") || [];

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Threat Detection</h1>
          <p className="text-slate-400">AI-powered threat analysis and classification</p>
        </div>

        {/* Threat Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">High Threats</p>
                  <p className="text-2xl font-bold text-red-400">{threats.length}</p>
                </div>
                <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Medium Threats</p>
                  <p className="text-2xl font-bold text-orange-400">{mediumThreats.length}</p>
                </div>
                <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <Shield className="w-6 h-6 text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Low Threats</p>
                  <p className="text-2xl font-bold text-green-400">{lowThreats.length}</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Activity className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Detection Rate</p>
                  <p className="text-2xl font-bold text-blue-400">94.2%</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Threat Details */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* High Priority Threats */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-red-400">High Priority Threats</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse p-4 bg-slate-700 rounded-lg">
                      <div className="h-4 bg-slate-600 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-slate-600 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : threats.length === 0 ? (
                <div className="text-center py-8">
                  <Shield className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <p className="text-slate-400">No high priority threats detected</p>
                  <p className="text-slate-500 text-sm">Your system is secure</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {threats.slice(0, 5).map((threat) => (
                    <div key={threat.id} className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-red-400">{threat.fileName}</h4>
                        <span className="text-sm text-slate-400">
                          {new Date(threat.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm text-slate-300 mb-2">
                        Type: {threat.scanType} | Confidence: {threat.confidenceScore}%
                      </p>
                      <div className="text-sm text-slate-400">
                        {Array.isArray(threat.results.threats) ? 
                          threat.results.threats.join(", ") : 
                          "Threat details not available"
                        }
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Medium Priority Threats */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-orange-400">Medium Priority Threats</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse p-4 bg-slate-700 rounded-lg">
                      <div className="h-4 bg-slate-600 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-slate-600 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : mediumThreats.length === 0 ? (
                <div className="text-center py-8">
                  <Shield className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <p className="text-slate-400">No medium priority threats detected</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {mediumThreats.slice(0, 5).map((threat) => (
                    <div key={threat.id} className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-orange-400">{threat.fileName}</h4>
                        <span className="text-sm text-slate-400">
                          {new Date(threat.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm text-slate-300 mb-2">
                        Type: {threat.scanType} | Confidence: {threat.confidenceScore}%
                      </p>
                      <div className="text-sm text-slate-400">
                        {Array.isArray(threat.results.threats) ? 
                          threat.results.threats.join(", ") : 
                          "Requires monitoring"
                        }
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
