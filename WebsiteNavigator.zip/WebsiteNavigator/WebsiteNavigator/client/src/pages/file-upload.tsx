import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CloudUpload, FileText, Download } from "lucide-react";
import type { Scan } from "@shared/schema";
export default function FileUpload() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [isDragOver, setIsDragOver] = useState(false);
  const { data: scans, isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans", user?.id],
    enabled: !!user?.id,
  });
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      if (!user) throw new Error("User not authenticated");
      
      // Simulate file upload with progress
      const fileName = file.name;
      const fileType = file.type || file.name.split('.').pop() || 'unknown';
      
      // Simulate upload progress
      for (let progress = 0; progress <= 100; progress += 10) {
        setUploadProgress(prev => ({ ...prev, [fileName]: progress }));
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      const scanData = {
        userId: user.id,
        fileName,
        fileType,
        scanType: fileType.includes('pdf') ? 'malware' : 'threat'
      };
      
      const response = await apiRequest("POST", "/api/scans", scanData);
      return response.json();
    },
    onSuccess: (scan) => {
      queryClient.invalidateQueries({ queryKey: ["/api/scans", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/threats/recent"] });
      
      toast({
        title: "File analyzed successfully",
        description: `Scan completed with ${scan.threatLevel} threat level`,
      });
      
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[scan.fileName];
        return newProgress;
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: "Failed to upload and analyze file",
      });
    },
  });
  const processFiles = (files: FileList | File[]) => {
    Array.from(files).forEach(file => {
      // Check file type
      const allowedTypes = ['.pdf', '.csv', '.txt', '.log'];
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
      
      if (!allowedTypes.includes(fileExtension)) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Only PDF, CSV, TXT, and LOG files are supported",
        });
        return;
      }
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast({
          variant: "destructive",
          title: "File too large",
          description: "File size must be less than 10MB",
        });
        return;
      }
      
      uploadMutation.mutate(file);
    });
  };
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;
    processFiles(files);
  };
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      processFiles(files);
    }
  };
  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(true);
  };
  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
  };
  const getThreatLevelColor = (level: string) => {
    switch (level) {
      case "high":
        return "text-red-400";
      case "medium":
        return "text-orange-400";
      default:
        return "text-green-400";
    }
  };
  const getThreatLevelVariant = (level: string) => {
    switch (level) {
      case "high":
        return "destructive";
      case "medium":
        return "secondary";
      default:
        return "outline";
    }
  };
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">File Upload & Analysis</h1>
          <p className="text-slate-400">Upload system logs, CSV files, or PDFs for AI-powered threat analysis</p>
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Upload Zone */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Upload Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div 
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                  isDragOver 
                    ? 'border-blue-400 bg-blue-500/10' 
                    : 'border-slate-600 hover:border-blue-500'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                <CloudUpload className={`w-12 h-12 mx-auto mb-4 ${isDragOver ? 'text-blue-400' : 'text-slate-400'}`} />
                <p className="text-lg font-medium mb-2">Drop files here or click to browse</p>
                <p className="text-slate-400 text-sm mb-4">Supported formats: PDF, CSV, TXT, LOG (Max 10MB)</p>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.csv,.txt,.log"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <Button className="bg-blue-500 hover:bg-blue-600">
                  Select Files
                </Button>
              </div>
              
              {/* Upload Progress */}
              {Object.entries(uploadProgress).length > 0 && (
                <div className="mt-6 space-y-3">
                  {Object.entries(uploadProgress).map(([fileName, progress]) => (
                    <div key={fileName} className="p-3 bg-slate-700 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-4 h-4 text-blue-400" />
                          <span className="text-sm">{fileName}</span>
                        </div>
                        <span className="text-xs text-slate-400">{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          {/* Analysis Results */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Analysis Results</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse p-4 bg-slate-700 rounded-lg">
                      <div className="h-4 bg-slate-600 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-slate-600 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : !scans || scans.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-400">No files analyzed yet</p>
                  <p className="text-slate-500 text-sm">Upload files to see analysis results</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {scans.slice(0, 5).map((scan) => (
                    <div key={scan.id} className="p-4 bg-slate-700 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{scan.fileName}</span>
                        <Badge variant={getThreatLevelVariant(scan.threatLevel)}>
                          {scan.status === "completed" ? "Complete" : "Processing"}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-slate-400">Threat Level</p>
                          <p className={`font-medium ${getThreatLevelColor(scan.threatLevel)}`}>
                            {scan.threatLevel.charAt(0).toUpperCase() + scan.threatLevel.slice(1)} ({scan.confidenceScore}/100)
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400">Confidence</p>
                          <p className="font-medium">{scan.confidenceScore}%</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="mt-3 text-blue-400 hover:text-blue-300">
                        <Download className="w-4 h-4 mr-1" />
                        Download Report
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}