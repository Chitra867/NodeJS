import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Upload, 
  Shield, 
  Bug, 
  Activity, 
  Search, 
  FileText 
} from "lucide-react";

const sidebarItems = [
  { href: "/dashboard", icon: BarChart3, label: "Dashboard" },
  { href: "/upload", icon: Upload, label: "Upload File" },
  { href: "/threat-detection", icon: Shield, label: "Threat Detection" },
  { href: "/malware-detection", icon: Bug, label: "Malware Detection" },
  { href: "/process-monitoring", icon: Activity, label: "Process Monitoring" },
  { href: "/real-time-scan", icon: Search, label: "Real-Time Scan" },
  { href: "/ai-report", icon: FileText, label: "AI Report" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-slate-800 min-h-screen border-r border-slate-700">
      <div className="p-6">
        <h3 className="text-lg font-semibold mb-4">Security Console</h3>
        <nav className="space-y-2">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? "text-blue-400 bg-blue-500/10"
                    : "text-slate-300 hover:text-white hover:bg-slate-700"
                }`}>
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
