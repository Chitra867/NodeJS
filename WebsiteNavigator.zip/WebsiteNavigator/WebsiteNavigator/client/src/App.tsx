import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthWrapper } from "@/components/auth/auth-provider";
import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/layout/navbar";

import Landing from "@/pages/landing";
import Login from "@/pages/auth/login";
import Signup from "@/pages/auth/signup";
import Dashboard from "@/pages/dashboard";
import FileUpload from "@/pages/file-upload";
import ProcessMonitoring from "@/pages/process-monitoring";
import ThreatDetection from "@/pages/threat-detection";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  
  if (!user) {
    return <Login />;
  }
  
  return <>{children}</>;
}

function Router() {
  const { user } = useAuth();

  return (
    <>
      <Navbar />
      <Switch>
        <Route path="/" component={user ? Dashboard : Landing} />
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/dashboard">
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        </Route>
        <Route path="/upload">
          <ProtectedRoute>
            <FileUpload />
          </ProtectedRoute>
        </Route>
        <Route path="/process-monitoring">
          <ProtectedRoute>
            <ProcessMonitoring />
          </ProtectedRoute>
        </Route>
        <Route path="/threat-detection">
          <ProtectedRoute>
            <ThreatDetection />
          </ProtectedRoute>
        </Route>
        <Route path="/malware-detection">
          <ProtectedRoute>
            <ThreatDetection />
          </ProtectedRoute>
        </Route>
        <Route path="/real-time-scan">
          <ProtectedRoute>
            <ProcessMonitoring />
          </ProtectedRoute>
        </Route>
        <Route path="/ai-report">
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthWrapper>
          <div className="min-h-screen bg-slate-900 text-slate-50">
            <Toaster />
            <Router />
          </div>
        </AuthWrapper>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
