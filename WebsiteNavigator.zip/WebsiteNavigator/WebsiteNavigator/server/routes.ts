import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, insertScanSchema, insertProcessSchema, insertThreatEventSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(409).json({ message: "User already exists" });
      }
      
      const user = await storage.createUser(userData);
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const allScans = await storage.getAllScans();
      const recentEvents = await storage.getRecentThreatEvents(10);
      
      const totalScans = allScans.length;
      const threatsDetected = allScans.filter(scan => scan.threatLevel === "high").length;
      const cleanFiles = allScans.filter(scan => scan.threatLevel === "low").length;
      const avgRiskScore = allScans.reduce((sum, scan) => sum + scan.confidenceScore, 0) / totalScans || 0;
      
      res.json({
        totalScans,
        threatsDetected,
        cleanFiles,
        riskScore: (avgRiskScore / 10).toFixed(1)
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Recent threat events
  app.get("/api/threats/recent", async (req, res) => {
    try {
      const events = await storage.getRecentThreatEvents(5);
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch threat events" });
    }
  });

  // File upload and scan
  app.post("/api/scans", async (req, res) => {
    try {
      const scanData = insertScanSchema.parse(req.body);
      
      // Simulate AI analysis
      const threatLevel = Math.random() > 0.7 ? "high" : Math.random() > 0.4 ? "medium" : "low";
      const confidenceScore = Math.floor(Math.random() * 30) + 70; // 70-100
      
      const results = {
        threats: threatLevel !== "low" ? [`Potential ${scanData.scanType} detected`] : [],
        recommendations: threatLevel === "high" ? ["Immediate action required", "Quarantine file"] : ["Monitor activity"]
      };
      
      const scan = await storage.createScan({
        ...scanData,
        threatLevel,
        confidenceScore,
        results
      });
      
      // Create threat event if high risk
      if (threatLevel === "high") {
        await storage.createThreatEvent({
          type: scanData.scanType,
          title: `${scanData.scanType.charAt(0).toUpperCase() + scanData.scanType.slice(1)} Detected`,
          description: `High-risk ${scanData.scanType} found in ${scanData.fileName}`,
          severity: "high",
          userId: scanData.userId,
          resolved: false
        });
      }
      
      res.status(201).json(scan);
    } catch (error) {
      res.status(400).json({ message: "Invalid scan data" });
    }
  });

  // Get user scans
  app.get("/api/scans/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const scans = await storage.getUserScans(userId);
      res.json(scans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scans" });
    }
  });

  // Process monitoring
  app.get("/api/processes/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const processes = await storage.getUserProcesses(userId);
      res.json(processes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch processes" });
    }
  });

  app.post("/api/processes", async (req, res) => {
    try {
      const processData = insertProcessSchema.parse(req.body);
      const process = await storage.createProcess(processData);
      res.status(201).json(process);
    } catch (error) {
      res.status(400).json({ message: "Invalid process data" });
    }
  });

  // Simulate system scan - generate mock processes
  app.post("/api/processes/scan/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const mockProcesses = [
        { name: "chrome.exe", cpuUsage: 12, memoryUsage: "256MB", riskScore: 15 },
        { name: "suspicious_process.exe", cpuUsage: 45, memoryUsage: "512MB", riskScore: 87 },
        { name: "banking_app.exe", cpuUsage: 23, memoryUsage: "128MB", riskScore: 60 },
        { name: "system32.exe", cpuUsage: 8, memoryUsage: "64MB", riskScore: 25 },
        { name: "notepad.exe", cpuUsage: 2, memoryUsage: "32MB", riskScore: 5 }
      ];
      
      const processes = [];
      for (const mockProcess of mockProcesses) {
        const pid = Math.floor(Math.random() * 9000) + 1000;
        const status = mockProcess.riskScore > 70 ? "suspicious" : "running";
        
        const process = await storage.createProcess({
          pid,
          name: mockProcess.name,
          cpuUsage: mockProcess.cpuUsage,
          memoryUsage: mockProcess.memoryUsage,
          riskScore: mockProcess.riskScore,
          status,
          userId
        });
        
        processes.push(process);
        
        // Create threat event for suspicious processes
        if (status === "suspicious") {
          await storage.createThreatEvent({
            type: "suspicious_process",
            title: "Suspicious Process Detected",
            description: `Process ${mockProcess.name} (PID: ${pid}) showing unusual behavior`,
            severity: "high",
            userId,
            resolved: false
          });
        }
      }
      
      res.json(processes);
    } catch (error) {
      res.status(500).json({ message: "Failed to perform system scan" });
    }
  });

  // Chart data
  app.get("/api/charts/threats", async (req, res) => {
    try {
      const data = {
        labels: ['Malware', 'Insider Threats', 'Phishing', 'Data Breach'],
        datasets: [{
          data: [35, 25, 20, 20],
          backgroundColor: ['#EF4444', '#F59E0B', '#8B5CF6', '#06B6D4']
        }]
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chart data" });
    }
  });

  app.get("/api/charts/timeline", async (req, res) => {
    try {
      const data = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Threats Detected',
          data: [12, 19, 3, 5, 2, 3],
          borderColor: '#EF4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)'
        }, {
          label: 'Clean Scans',
          data: [65, 59, 80, 81, 56, 55],
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)'
        }]
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch timeline data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
