# AI-Integrated Predictive Behavioral Analytics Framework

A professional cybersecurity web application for detecting insider threats and malware through system process monitoring, specifically designed for financial institutions in the Kathmandu Valley.

## 🔥 Features

- **AI-Powered Threat Detection**: Advanced machine learning algorithms for insider threat and malware detection
- **Real-Time Process Monitoring**: Continuous system monitoring with risk assessment
- **File Analysis**: Upload and analyze system logs, PDFs, and CSV files
- **Interactive Dashboard**: Real-time charts and statistics
- **Role-Based Authentication**: Admin, analyst, and user roles
- **Professional UI**: Dark-themed, responsive design built for financial institutions

## 🚀 Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development
- **Tailwind CSS** for styling
- **Radix UI** components
- **TanStack Query** for state management
- **Wouter** for routing
- **Chart.js** for data visualization

### Backend
- **Node.js** with Express.js
- **TypeScript** with ES modules
- **Drizzle ORM** with PostgreSQL
- **In-memory storage** for development
- **RESTful API** design

### Database
- **PostgreSQL** (Neon serverless ready)
- **Drizzle Kit** for migrations

## 📁 Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Application pages
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utility libraries
│   │   └── index.css      # Global styles
│   └── index.html
├── server/                # Backend Express application
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Data storage layer
│   └── vite.ts           # Vite integration
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schema and types
├── package.json
├── tailwind.config.ts
├── vite.config.ts
└── drizzle.config.ts
```

## 🛠️ Setup Instructions

### Prerequisites
- Node.js 18+ installed
- PostgreSQL database (optional for development)

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Setup
Create a `.env` file in the root directory:
```bash
# Database (optional for development)
DATABASE_URL="postgresql://username:password@localhost:5432/secureai"

# Development
NODE_ENV=development
```

### 3. Database Setup (Optional)
For production with PostgreSQL:
```bash
# Push schema to database
npm run db:push

# Generate migrations
npm run db:generate
```

### 4. Start Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 🔐 Default Credentials

For testing, use these default credentials:
- **Email**: admin@secureai.com
- **Password**: admin123
- **Role**: Administrator

## 📊 Key Components

### Authentication System
- Secure login/signup with role-based access
- JWT-style session management
- Protected routes for authenticated users

### Dashboard
- Real-time threat statistics
- Interactive charts (pie charts, timelines)
- Recent security events feed
- System health monitoring

### File Upload & Analysis
- Multi-file upload support (PDF, CSV, TXT, LOG)
- AI-powered threat analysis simulation
- Confidence scoring and threat classification
- Downloadable reports

### Process Monitoring
- Real-time system process scanning
- Risk assessment with visual indicators
- Suspicious process detection
- Process management controls

### Threat Detection
- Threat classification (High, Medium, Low)
- Detailed threat analysis
- Historical threat tracking
- Actionable security recommendations

## 🎨 Design Features

- **Professional Dark Theme**: Designed for security professionals
- **Responsive Design**: Works on desktop and mobile devices
- **Accessibility**: Built with Radix UI for screen reader support
- **Modern UI**: Clean, intuitive interface with security-focused design
- **Visual Indicators**: Color-coded threat levels and status indicators

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/signup` - User registration

### Dashboard
- `GET /api/dashboard/stats` - Dashboard statistics
- `GET /api/threats/recent` - Recent threat events

### File Analysis
- `POST /api/scans` - Upload and analyze files
- `GET /api/scans/:userId` - Get user's scan results

### Process Monitoring
- `GET /api/processes/:userId` - Get user's processes
- `POST /api/processes/scan/:userId` - Start system scan

### Charts & Analytics
- `GET /api/charts/threats` - Threat distribution data
- `GET /api/charts/timeline` - Detection timeline data

## 🚢 Deployment

### Development
The application uses in-memory storage for development, making it easy to test without database setup.

### Production
1. Set up PostgreSQL database
2. Configure `DATABASE_URL` environment variable
3. Run database migrations: `npm run db:push`
4. Build the application: `npm run build`
5. Deploy to your preferred hosting platform

### Recommended Hosting
- **Frontend**: Vercel, Netlify, or any static hosting
- **Backend**: Railway, Render, or traditional VPS
- **Database**: Neon, Supabase, or managed PostgreSQL

## 🔒 Security Features

- **Input Validation**: Zod schema validation on all endpoints
- **Error Handling**: Comprehensive error handling and logging
- **Session Security**: Secure session management
- **File Upload Security**: File type and size validation
- **SQL Injection Protection**: Drizzle ORM prevents SQL injection

## 📈 Monitoring & Analytics

The application includes built-in monitoring for:
- Threat detection rates
- System performance metrics
- User activity tracking
- Security event logging
- Process risk assessment

## 🎯 Use Cases

Perfect for:
- Financial institutions requiring security monitoring
- IT security teams needing threat detection
- Compliance teams tracking security events
- System administrators monitoring processes
- Security analysts investigating threats

## 📝 License

This project is created for cybersecurity research and educational purposes for financial institutions in the Kathmandu Valley.

## 🤝 Support

For questions or support, please contact the development team or refer to the project documentation.

---

**Built with ❤️ for Enhanced Financial Security in Kathmandu Valley**