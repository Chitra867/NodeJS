import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Bug, CheckCircle } from "lucide-react";
import type { ThreatEvent } from "@shared/schema";

export function RecentEvents() {
  const { data: events, isLoading } = useQuery<ThreatEvent[]>({
    queryKey: ["/api/threats/recent"],
  });

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle>Recent Security Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse p-4 bg-slate-700 rounded-lg">
                <div className="h-4 bg-slate-600 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-slate-600 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!events || events.length === 0) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle>Recent Security Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
            <p className="text-slate-400">No recent security events</p>
            <p className="text-slate-500 text-sm">Your system is secure</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getEventIcon = (type: string) => {
    switch (type) {
      case "malware":
        return <Bug className="w-5 h-5 text-red-400" />;
      case "suspicious_process":
        return <AlertTriangle className="w-5 h-5 text-orange-400" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-red-400" />;
    }
  };

  const getSeverityVariant = (severity: string) => {
    switch (severity) {
      case "high":
      case "critical":
        return "destructive";
      case "medium":
        return "secondary";
      default:
        return "outline";
    }
  };

  const formatTimeAgo = (date: string | Date) => {
    const now = new Date();
    const eventDate = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - eventDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle>Recent Security Events</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center">
                  {getEventIcon(event.type)}
                </div>
                <div>
                  <p className="font-medium">{event.title}</p>
                  <p className="text-sm text-slate-400">{event.description}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-400 mb-1">
                  {formatTimeAgo(event.createdAt)}
                </p>
                <Badge variant={getSeverityVariant(event.severity)}>
                  {event.severity.charAt(0).toUpperCase() + event.severity.slice(1)} Risk
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
