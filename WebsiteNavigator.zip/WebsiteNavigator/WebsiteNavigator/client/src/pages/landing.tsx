import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Shield, 
  Brain, 
  Activity, 
  TrendingUp, 
  FileCheck, 
  Bug, 
  FileText,
  ArrowRight,
  CheckCircle
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Brain,
      title: "AI Threat Detection",
      description: "Advanced machine learning algorithms detect insider threats and malware with high accuracy",
      color: "blue"
    },
    {
      icon: Activity,
      title: "Real-Time Monitoring",
      description: "Continuous system process monitoring with real-time threat assessment and alerts",
      color: "green"
    },
    {
      icon: TrendingUp,
      title: "Behavioral Analytics",
      description: "Predictive analytics to identify unusual patterns and potential security breaches",
      color: "purple"
    },
    {
      icon: FileCheck,
      title: "File Analysis",
      description: "Upload and analyze system logs, PDFs, and CSV files for threat assessment",
      color: "orange"
    },
    {
      icon: Bug,
      title: "Malware Detection",
      description: "Sophisticated malware identification and classification with confidence scoring",
      color: "red"
    },
    {
      icon: FileText,
      title: "Detailed Reports",
      description: "Comprehensive PDF reports with actionable insights and security recommendations",
      color: "cyan"
    }
  ];

  const steps = [
    {
      number: 1,
      title: "Upload Files",
      description: "Upload system logs, process data, or security files for analysis",
      color: "from-blue-500 to-cyan-500"
    },
    {
      number: 2,
      title: "AI Analysis",
      description: "Our AI algorithms analyze patterns and behaviors for threats",
      color: "from-green-500 to-emerald-500"
    },
    {
      number: 3,
      title: "Risk Assessment",
      description: "Get detailed risk scores and threat classifications",
      color: "from-purple-500 to-pink-500"
    },
    {
      number: 4,
      title: "Take Action",
      description: "Receive actionable recommendations and detailed reports",
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900">


      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 gradient-text">
              AI-Integrated Predictive Behavioral Analytics
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-4 font-medium">
              For Detecting Insider Threats and Malware through System Process Monitoring
            </p>
            <p className="text-lg text-slate-400 mb-8">
              Enhancing Data Security in Financial Institutions of the Kathmandu Valley
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-lg">
                  <ArrowRight className="w-5 h-5 mr-2" />
                  Get Started
                </Button>
              </Link>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:text-white hover:border-slate-500 px-8 py-3 text-lg">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Advanced Security Features</h2>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto">
              Our AI-powered platform provides comprehensive threat detection and monitoring capabilities
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="bg-slate-800 border-slate-700 hover:border-blue-500/50 transition-all hover:transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 bg-${feature.color}-500/20 rounded-lg flex items-center justify-center mb-4`}>
                      <Icon className={`w-6 h-6 text-${feature.color}-400`} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-slate-400">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto">
              Four simple steps to comprehensive security monitoring
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl`}>
                  {step.number}
                </div>
                <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                <p className="text-slate-400">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-xl text-slate-400">Ready to enhance your financial institution's security?</p>
          </div>
          
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-8">
              <form className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <Input 
                    placeholder="Your name" 
                    className="bg-slate-700 border-slate-600"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input 
                    type="email" 
                    placeholder="your@email.com" 
                    className="bg-slate-700 border-slate-600"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <Textarea 
                    rows={4} 
                    placeholder="Tell us about your security needs..." 
                    className="bg-slate-700 border-slate-600"
                  />
                </div>
                <div className="md:col-span-2">
                  <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                    Send Message
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold">SecureAI</span>
            </div>
            <p className="text-slate-400 mb-4">
              AI-Integrated Predictive Behavioral Analytics for Financial Security
            </p>
            <p className="text-sm text-slate-500">
              © 2024 SecureAI Platform. Kathmandu Valley Financial Security Initiative.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
